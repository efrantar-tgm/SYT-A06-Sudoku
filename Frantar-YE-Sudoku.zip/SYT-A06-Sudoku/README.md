SYT-A06-Sudoku
==============

SYT-IndInf-06 "Sudoku"
