#ifndef SUDOKU9X9_H_INCLUDED
#define SUDOKU9X9_H_INCLUDED

#include <stdio.h>
#include <stdint.h>
#include "sudoku.h"

sudoku* solve9x9(sudoku*);

#endif
