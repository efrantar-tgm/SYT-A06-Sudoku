#ifndef SOLVEX_H_INCLUDED
#define SOLVEX_H_INCLUDED

#include <stdint.h>
#include "sudoku.h"

sudoku* solvex(sudoku*);

#endif
