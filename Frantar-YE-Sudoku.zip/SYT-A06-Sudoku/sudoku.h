#ifndef SUDOKU_H_INCLUDED
#define SUDOKU_H_INCLUDED

typedef struct{
  int grid[9][9];
  int type;
} sudoku;

#endif
